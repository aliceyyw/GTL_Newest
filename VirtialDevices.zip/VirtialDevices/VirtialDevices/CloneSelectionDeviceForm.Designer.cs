﻿namespace VirtialDevices
{
    partial class CloneSelectionDeviceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.closeButton = new System.Windows.Forms.Button();
            this.confirmButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.jieZhongZhenDongTextBox = new System.Windows.Forms.TextBox();
            this.jieZhongTingLiuShiJianTextBox = new System.Windows.Forms.TextBox();
            this.tiaoXuanTingLiuShiJianTextBox = new System.Windows.Forms.TextBox();
            this.tiaoXuanZongShuTextBox = new System.Windows.Forms.TextBox();
            this.gongZuoFangShiTextBox = new System.Windows.Forms.TextBox();
            this.kongBanLeiXingTextBox = new System.Windows.Forms.TextBox();
            this.pingMinLeiXingTextBox = new System.Windows.Forms.TextBox();
            this.zhaoMingFangShiTextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.qingXiCiShuTextBox = new System.Windows.Forms.TextBox();
            this.qingXiShiJianTextBox = new System.Windows.Forms.TextBox();
            this.chouQiTextBox = new System.Windows.Forms.TextBox();
            this.lengQueTextBox = new System.Windows.Forms.TextBox();
            this.jiaReTextBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.jingBiZhiUpperTextBox = new System.Windows.Forms.TextBox();
            this.jingBiZhiLowerTextBox = new System.Windows.Forms.TextBox();
            this.duanJingUpperTextBox = new System.Windows.Forms.TextBox();
            this.duanJingLowerTextBox = new System.Windows.Forms.TextBox();
            this.changJingUpperTextBox = new System.Windows.Forms.TextBox();
            this.changJingLowerTextBox = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.biZhiUpperTextBox = new System.Windows.Forms.TextBox();
            this.biZhiLowerTextBox = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.areaUpperTextBox = new System.Windows.Forms.TextBox();
            this.areaLowerTextBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.colorBTextBox = new System.Windows.Forms.TextBox();
            this.colorGTextBox = new System.Windows.Forms.TextBox();
            this.colorRTextBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.PicButton = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label3 = new System.Windows.Forms.Label();
            this.shiBieHouPictureBox = new System.Windows.Forms.PictureBox();
            this.junLuoPictureBox = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shiBieHouPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.junLuoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.closeButton);
            this.panel1.Controls.Add(this.confirmButton);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(12, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(647, 543);
            this.panel1.TabIndex = 0;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(545, 507);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 25);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "关闭";
            this.closeButton.UseVisualStyleBackColor = true;
            // 
            // confirmButton
            // 
            this.confirmButton.Location = new System.Drawing.Point(26, 507);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(75, 25);
            this.confirmButton.TabIndex = 1;
            this.confirmButton.Text = "确认";
            this.confirmButton.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(641, 505);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(633, 479);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "配置";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.jieZhongZhenDongTextBox);
            this.panel3.Controls.Add(this.jieZhongTingLiuShiJianTextBox);
            this.panel3.Controls.Add(this.tiaoXuanTingLiuShiJianTextBox);
            this.panel3.Controls.Add(this.tiaoXuanZongShuTextBox);
            this.panel3.Controls.Add(this.gongZuoFangShiTextBox);
            this.panel3.Controls.Add(this.kongBanLeiXingTextBox);
            this.panel3.Controls.Add(this.pingMinLeiXingTextBox);
            this.panel3.Controls.Add(this.zhaoMingFangShiTextBox);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(6, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(621, 404);
            this.panel3.TabIndex = 0;
            // 
            // jieZhongZhenDongTextBox
            // 
            this.jieZhongZhenDongTextBox.Location = new System.Drawing.Point(439, 117);
            this.jieZhongZhenDongTextBox.Name = "jieZhongZhenDongTextBox";
            this.jieZhongZhenDongTextBox.Size = new System.Drawing.Size(154, 20);
            this.jieZhongZhenDongTextBox.TabIndex = 21;
            this.jieZhongZhenDongTextBox.Text = "4";
            // 
            // jieZhongTingLiuShiJianTextBox
            // 
            this.jieZhongTingLiuShiJianTextBox.Location = new System.Drawing.Point(135, 146);
            this.jieZhongTingLiuShiJianTextBox.Name = "jieZhongTingLiuShiJianTextBox";
            this.jieZhongTingLiuShiJianTextBox.Size = new System.Drawing.Size(154, 20);
            this.jieZhongTingLiuShiJianTextBox.TabIndex = 20;
            this.jieZhongTingLiuShiJianTextBox.Text = "5";
            // 
            // tiaoXuanTingLiuShiJianTextBox
            // 
            this.tiaoXuanTingLiuShiJianTextBox.Location = new System.Drawing.Point(135, 117);
            this.tiaoXuanTingLiuShiJianTextBox.Name = "tiaoXuanTingLiuShiJianTextBox";
            this.tiaoXuanTingLiuShiJianTextBox.Size = new System.Drawing.Size(154, 20);
            this.tiaoXuanTingLiuShiJianTextBox.TabIndex = 19;
            this.tiaoXuanTingLiuShiJianTextBox.Text = "3";
            // 
            // tiaoXuanZongShuTextBox
            // 
            this.tiaoXuanZongShuTextBox.Location = new System.Drawing.Point(439, 51);
            this.tiaoXuanZongShuTextBox.Multiline = true;
            this.tiaoXuanZongShuTextBox.Name = "tiaoXuanZongShuTextBox";
            this.tiaoXuanZongShuTextBox.Size = new System.Drawing.Size(154, 20);
            this.tiaoXuanZongShuTextBox.TabIndex = 18;
            this.tiaoXuanZongShuTextBox.Text = "5";
            // 
            // gongZuoFangShiTextBox
            // 
            this.gongZuoFangShiTextBox.Location = new System.Drawing.Point(439, 22);
            this.gongZuoFangShiTextBox.Multiline = true;
            this.gongZuoFangShiTextBox.Name = "gongZuoFangShiTextBox";
            this.gongZuoFangShiTextBox.Size = new System.Drawing.Size(154, 20);
            this.gongZuoFangShiTextBox.TabIndex = 17;
            this.gongZuoFangShiTextBox.Text = "并行";
            // 
            // kongBanLeiXingTextBox
            // 
            this.kongBanLeiXingTextBox.Location = new System.Drawing.Point(111, 79);
            this.kongBanLeiXingTextBox.Multiline = true;
            this.kongBanLeiXingTextBox.Name = "kongBanLeiXingTextBox";
            this.kongBanLeiXingTextBox.Size = new System.Drawing.Size(154, 20);
            this.kongBanLeiXingTextBox.TabIndex = 16;
            this.kongBanLeiXingTextBox.Text = "双层薄膜型";
            // 
            // pingMinLeiXingTextBox
            // 
            this.pingMinLeiXingTextBox.Location = new System.Drawing.Point(111, 50);
            this.pingMinLeiXingTextBox.Multiline = true;
            this.pingMinLeiXingTextBox.Name = "pingMinLeiXingTextBox";
            this.pingMinLeiXingTextBox.Size = new System.Drawing.Size(154, 20);
            this.pingMinLeiXingTextBox.TabIndex = 15;
            this.pingMinLeiXingTextBox.Text = "平直";
            // 
            // zhaoMingFangShiTextBox
            // 
            this.zhaoMingFangShiTextBox.Location = new System.Drawing.Point(111, 21);
            this.zhaoMingFangShiTextBox.Multiline = true;
            this.zhaoMingFangShiTextBox.Name = "zhaoMingFangShiTextBox";
            this.zhaoMingFangShiTextBox.Size = new System.Drawing.Size(154, 20);
            this.zhaoMingFangShiTextBox.TabIndex = 14;
            this.zhaoMingFangShiTextBox.Text = "2级柔光";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.qingXiCiShuTextBox);
            this.panel4.Controls.Add(this.qingXiShiJianTextBox);
            this.panel4.Controls.Add(this.chouQiTextBox);
            this.panel4.Controls.Add(this.lengQueTextBox);
            this.panel4.Controls.Add(this.jiaReTextBox);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Location = new System.Drawing.Point(3, 198);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(615, 129);
            this.panel4.TabIndex = 13;
            // 
            // qingXiCiShuTextBox
            // 
            this.qingXiCiShuTextBox.Location = new System.Drawing.Point(441, 69);
            this.qingXiCiShuTextBox.Name = "qingXiCiShuTextBox";
            this.qingXiCiShuTextBox.Size = new System.Drawing.Size(154, 20);
            this.qingXiCiShuTextBox.TabIndex = 25;
            // 
            // qingXiShiJianTextBox
            // 
            this.qingXiShiJianTextBox.Location = new System.Drawing.Point(441, 39);
            this.qingXiShiJianTextBox.Name = "qingXiShiJianTextBox";
            this.qingXiShiJianTextBox.Size = new System.Drawing.Size(154, 20);
            this.qingXiShiJianTextBox.TabIndex = 24;
            // 
            // chouQiTextBox
            // 
            this.chouQiTextBox.Location = new System.Drawing.Point(152, 98);
            this.chouQiTextBox.Name = "chouQiTextBox";
            this.chouQiTextBox.Size = new System.Drawing.Size(154, 20);
            this.chouQiTextBox.TabIndex = 23;
            // 
            // lengQueTextBox
            // 
            this.lengQueTextBox.Location = new System.Drawing.Point(152, 68);
            this.lengQueTextBox.Name = "lengQueTextBox";
            this.lengQueTextBox.Size = new System.Drawing.Size(154, 20);
            this.lengQueTextBox.TabIndex = 22;
            // 
            // jiaReTextBox
            // 
            this.jiaReTextBox.Location = new System.Drawing.Point(152, 39);
            this.jiaReTextBox.Name = "jiaReTextBox";
            this.jiaReTextBox.Size = new System.Drawing.Size(154, 20);
            this.jiaReTextBox.TabIndex = 21;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "灭菌和清洗";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "加热时间(10秒)：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(334, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "清洗时间(10秒)：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(334, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "清洗次数(次)：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(45, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "抽气时间(秒)：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(45, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "冷却时间(10秒)：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(306, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "接种振动(次)：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "接种停留时间：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "挑选停留时间：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(306, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "从培养皿挑选总数：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "照明方式：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(306, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "工作方式：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "孔板类型：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "平皿类型：";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(633, 479);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "条件";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.jingBiZhiUpperTextBox);
            this.panel5.Controls.Add(this.jingBiZhiLowerTextBox);
            this.panel5.Controls.Add(this.duanJingUpperTextBox);
            this.panel5.Controls.Add(this.duanJingLowerTextBox);
            this.panel5.Controls.Add(this.changJingUpperTextBox);
            this.panel5.Controls.Add(this.changJingLowerTextBox);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.label33);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label30);
            this.panel5.Controls.Add(this.label29);
            this.panel5.Controls.Add(this.biZhiUpperTextBox);
            this.panel5.Controls.Add(this.biZhiLowerTextBox);
            this.panel5.Controls.Add(this.label28);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.areaUpperTextBox);
            this.panel5.Controls.Add(this.areaLowerTextBox);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.colorBTextBox);
            this.panel5.Controls.Add(this.colorGTextBox);
            this.panel5.Controls.Add(this.colorRTextBox);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Location = new System.Drawing.Point(6, 7);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(621, 404);
            this.panel5.TabIndex = 0;
            // 
            // jingBiZhiUpperTextBox
            // 
            this.jingBiZhiUpperTextBox.Location = new System.Drawing.Point(437, 333);
            this.jingBiZhiUpperTextBox.Name = "jingBiZhiUpperTextBox";
            this.jingBiZhiUpperTextBox.Size = new System.Drawing.Size(100, 20);
            this.jingBiZhiUpperTextBox.TabIndex = 30;
            // 
            // jingBiZhiLowerTextBox
            // 
            this.jingBiZhiLowerTextBox.Location = new System.Drawing.Point(437, 303);
            this.jingBiZhiLowerTextBox.Name = "jingBiZhiLowerTextBox";
            this.jingBiZhiLowerTextBox.Size = new System.Drawing.Size(100, 20);
            this.jingBiZhiLowerTextBox.TabIndex = 29;
            // 
            // duanJingUpperTextBox
            // 
            this.duanJingUpperTextBox.Location = new System.Drawing.Point(437, 274);
            this.duanJingUpperTextBox.Name = "duanJingUpperTextBox";
            this.duanJingUpperTextBox.Size = new System.Drawing.Size(100, 20);
            this.duanJingUpperTextBox.TabIndex = 28;
            // 
            // duanJingLowerTextBox
            // 
            this.duanJingLowerTextBox.Location = new System.Drawing.Point(437, 245);
            this.duanJingLowerTextBox.Name = "duanJingLowerTextBox";
            this.duanJingLowerTextBox.Size = new System.Drawing.Size(100, 20);
            this.duanJingLowerTextBox.TabIndex = 27;
            // 
            // changJingUpperTextBox
            // 
            this.changJingUpperTextBox.Location = new System.Drawing.Point(437, 216);
            this.changJingUpperTextBox.Name = "changJingUpperTextBox";
            this.changJingUpperTextBox.Size = new System.Drawing.Size(100, 20);
            this.changJingUpperTextBox.TabIndex = 26;
            // 
            // changJingLowerTextBox
            // 
            this.changJingLowerTextBox.Location = new System.Drawing.Point(437, 186);
            this.changJingLowerTextBox.Name = "changJingLowerTextBox";
            this.changJingLowerTextBox.Size = new System.Drawing.Size(100, 20);
            this.changJingLowerTextBox.TabIndex = 25;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(350, 338);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 13);
            this.label35.TabIndex = 24;
            this.label35.Text = "比值上限：";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(350, 310);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(67, 13);
            this.label34.TabIndex = 23;
            this.label34.Text = "比值下限：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(350, 280);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 13);
            this.label33.TabIndex = 22;
            this.label33.Text = "短径上限：";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(350, 250);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 13);
            this.label32.TabIndex = 21;
            this.label32.Text = "短径下限：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(350, 221);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 13);
            this.label31.TabIndex = 20;
            this.label31.Text = "长径上限：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(350, 192);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 13);
            this.label30.TabIndex = 19;
            this.label30.Text = "长径下限：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(311, 155);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(115, 13);
            this.label29.TabIndex = 18;
            this.label29.Text = "长短径筛选选项设定";
            // 
            // biZhiUpperTextBox
            // 
            this.biZhiUpperTextBox.Location = new System.Drawing.Point(127, 248);
            this.biZhiUpperTextBox.Name = "biZhiUpperTextBox";
            this.biZhiUpperTextBox.Size = new System.Drawing.Size(100, 20);
            this.biZhiUpperTextBox.TabIndex = 17;
            // 
            // biZhiLowerTextBox
            // 
            this.biZhiLowerTextBox.Location = new System.Drawing.Point(127, 219);
            this.biZhiLowerTextBox.Name = "biZhiLowerTextBox";
            this.biZhiLowerTextBox.Size = new System.Drawing.Size(100, 20);
            this.biZhiLowerTextBox.TabIndex = 16;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(56, 252);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 13);
            this.label28.TabIndex = 15;
            this.label28.Text = "比值上限：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(56, 224);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(67, 13);
            this.label27.TabIndex = 14;
            this.label27.Text = "比值下限：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(28, 191);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(139, 13);
            this.label26.TabIndex = 13;
            this.label26.Text = "周长面积比筛选选项设定";
            // 
            // areaUpperTextBox
            // 
            this.areaUpperTextBox.Location = new System.Drawing.Point(418, 75);
            this.areaUpperTextBox.Name = "areaUpperTextBox";
            this.areaUpperTextBox.Size = new System.Drawing.Size(100, 20);
            this.areaUpperTextBox.TabIndex = 12;
            // 
            // areaLowerTextBox
            // 
            this.areaLowerTextBox.Location = new System.Drawing.Point(418, 46);
            this.areaLowerTextBox.Name = "areaLowerTextBox";
            this.areaLowerTextBox.Size = new System.Drawing.Size(100, 20);
            this.areaLowerTextBox.TabIndex = 11;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(348, 79);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 13);
            this.label25.TabIndex = 10;
            this.label25.Text = "面积下限：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(348, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 13);
            this.label24.TabIndex = 9;
            this.label24.Text = "面积上限：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(309, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "面积筛选选项设定";
            // 
            // colorBTextBox
            // 
            this.colorBTextBox.Location = new System.Drawing.Point(121, 130);
            this.colorBTextBox.Name = "colorBTextBox";
            this.colorBTextBox.Size = new System.Drawing.Size(49, 20);
            this.colorBTextBox.TabIndex = 7;
            // 
            // colorGTextBox
            // 
            this.colorGTextBox.Location = new System.Drawing.Point(121, 100);
            this.colorGTextBox.Name = "colorGTextBox";
            this.colorGTextBox.Size = new System.Drawing.Size(49, 20);
            this.colorGTextBox.TabIndex = 6;
            // 
            // colorRTextBox
            // 
            this.colorRTextBox.Location = new System.Drawing.Point(121, 69);
            this.colorRTextBox.Name = "colorRTextBox";
            this.colorRTextBox.Size = new System.Drawing.Size(49, 20);
            this.colorRTextBox.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(91, 134);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "B：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(91, 104);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(27, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "G：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(91, 74);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(27, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "R：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(54, 46);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(139, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "色度平均值筛选选项设定";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "筛选（挑选）条件设定";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(633, 479);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "数据";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.PicButton);
            this.panel2.Controls.Add(this.listView1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.shiBieHouPictureBox);
            this.panel2.Controls.Add(this.junLuoPictureBox);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(6, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(621, 469);
            this.panel2.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(156, 282);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(43, 13);
            this.label37.TabIndex = 12;
            this.label37.Text = "仿真数";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(206, 275);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(61, 20);
            this.textBox2.TabIndex = 11;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(156, 316);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(79, 13);
            this.label36.TabIndex = 10;
            this.label36.Text = "数据存储路径";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(241, 313);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(319, 20);
            this.textBox1.TabIndex = 9;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(485, 277);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "导入";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.daoRuButton_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(321, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "生成";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.shengchengButton_Click);
            // 
            // PicButton
            // 
            this.PicButton.Location = new System.Drawing.Point(124, 13);
            this.PicButton.Name = "PicButton";
            this.PicButton.Size = new System.Drawing.Size(75, 23);
            this.PicButton.TabIndex = 6;
            this.PicButton.Text = "选取文件";
            this.PicButton.UseVisualStyleBackColor = true;
            this.PicButton.Click += new System.EventHandler(this.PicButton_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(13, 339);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(594, 123);
            this.listView1.TabIndex = 5;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "序号";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "位置";
            this.columnHeader2.Width = 40;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "颜色";
            this.columnHeader3.Width = 40;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "质心位置";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "面积";
            this.columnHeader5.Width = 40;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "周长";
            this.columnHeader6.Width = 40;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "面积周长比";
            this.columnHeader7.Width = 80;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "长泾";
            this.columnHeader8.Width = 40;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "短径";
            this.columnHeader9.Width = 40;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "长短径比";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "条码";
            this.columnHeader11.Width = 40;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "空号";
            this.columnHeader12.Width = 40;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "数据";
            // 
            // shiBieHouPictureBox
            // 
            this.shiBieHouPictureBox.Location = new System.Drawing.Point(321, 51);
            this.shiBieHouPictureBox.Name = "shiBieHouPictureBox";
            this.shiBieHouPictureBox.Size = new System.Drawing.Size(239, 203);
            this.shiBieHouPictureBox.TabIndex = 3;
            this.shiBieHouPictureBox.TabStop = false;
            // 
            // junLuoPictureBox
            // 
            this.junLuoPictureBox.Location = new System.Drawing.Point(28, 51);
            this.junLuoPictureBox.Name = "junLuoPictureBox";
            this.junLuoPictureBox.Size = new System.Drawing.Size(239, 203);
            this.junLuoPictureBox.TabIndex = 2;
            this.junLuoPictureBox.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(318, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "识别后图像";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "菌落图像";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // CloneSelectionDeviceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 568);
            this.Controls.Add(this.panel1);
            this.Name = "CloneSelectionDeviceForm";
            this.Text = "全自动单克隆挑选仪";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CloneSelectionDeviceForm_FormClosing);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shiBieHouPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.junLuoPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox shiBieHouPictureBox;
        private System.Windows.Forms.PictureBox junLuoPictureBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox zhaoMingFangShiTextBox;
        private System.Windows.Forms.TextBox tiaoXuanZongShuTextBox;
        private System.Windows.Forms.TextBox gongZuoFangShiTextBox;
        private System.Windows.Forms.TextBox kongBanLeiXingTextBox;
        private System.Windows.Forms.TextBox pingMinLeiXingTextBox;
        private System.Windows.Forms.TextBox jieZhongTingLiuShiJianTextBox;
        private System.Windows.Forms.TextBox tiaoXuanTingLiuShiJianTextBox;
        private System.Windows.Forms.TextBox jieZhongZhenDongTextBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox chouQiTextBox;
        private System.Windows.Forms.TextBox lengQueTextBox;
        private System.Windows.Forms.TextBox jiaReTextBox;
        private System.Windows.Forms.TextBox qingXiCiShuTextBox;
        private System.Windows.Forms.TextBox qingXiShiJianTextBox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox colorBTextBox;
        private System.Windows.Forms.TextBox colorGTextBox;
        private System.Windows.Forms.TextBox colorRTextBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox areaUpperTextBox;
        private System.Windows.Forms.TextBox areaLowerTextBox;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox biZhiUpperTextBox;
        private System.Windows.Forms.TextBox biZhiLowerTextBox;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox jingBiZhiUpperTextBox;
        private System.Windows.Forms.TextBox jingBiZhiLowerTextBox;
        private System.Windows.Forms.TextBox duanJingUpperTextBox;
        private System.Windows.Forms.TextBox duanJingLowerTextBox;
        private System.Windows.Forms.TextBox changJingUpperTextBox;
        private System.Windows.Forms.TextBox changJingLowerTextBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button PicButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox2;
    }
}