﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DeviceUtils;
using Instrument;

namespace VirtialDevices
{
    public class CheckUtil
    {
        public static bool checkIP(String ip)
        {
            return true;
        }

        public static bool checkTime(String time) 
        {
            return true;
        }

        public static bool checkCode(String code) 
        {
            return true;
        }

        public static bool checkIdentify(String identify) 
        {
            return true;
        }

        public static Boolean checkSerial(String serial) 
        {
            return true;
        }

    }
}
