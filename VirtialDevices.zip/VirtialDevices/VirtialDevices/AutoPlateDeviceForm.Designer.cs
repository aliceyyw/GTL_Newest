﻿namespace VirtialDevices
{
    partial class AutoPlateDeviceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.displayPanel = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.leftNumberTextBox = new System.Windows.Forms.TextBox();
            this.leftNumberLabel = new System.Windows.Forms.Label();
            this.capTextBox = new System.Windows.Forms.TextBox();
            this.capLabel = new System.Windows.Forms.Label();
            this.totalNumberTextBox = new System.Windows.Forms.TextBox();
            this.totalNumberLabel = new System.Windows.Forms.Label();
            this.settingPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.setButton = new System.Windows.Forms.Button();
            this.sampleTimeTextBox = new System.Windows.Forms.TextBox();
            this.dispenTimeTextBox = new System.Windows.Forms.TextBox();
            this.currency3TextBox = new System.Windows.Forms.TextBox();
            this.currency2TextBox = new System.Windows.Forms.TextBox();
            this.currency1TextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.stateComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.displayPanel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.settingPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.displayPanel);
            this.panel1.Controls.Add(this.settingPanel);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(527, 307);
            this.panel1.TabIndex = 0;
            // 
            // displayPanel
            // 
            this.displayPanel.Controls.Add(this.groupBox2);
            this.displayPanel.Location = new System.Drawing.Point(331, 3);
            this.displayPanel.Name = "displayPanel";
            this.displayPanel.Size = new System.Drawing.Size(193, 301);
            this.displayPanel.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.leftNumberTextBox);
            this.groupBox2.Controls.Add(this.leftNumberLabel);
            this.groupBox2.Controls.Add(this.capTextBox);
            this.groupBox2.Controls.Add(this.capLabel);
            this.groupBox2.Controls.Add(this.totalNumberTextBox);
            this.groupBox2.Controls.Add(this.totalNumberLabel);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 293);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "显示";
            // 
            // leftNumberTextBox
            // 
            this.leftNumberTextBox.Enabled = false;
            this.leftNumberTextBox.Location = new System.Drawing.Point(44, 225);
            this.leftNumberTextBox.Name = "leftNumberTextBox";
            this.leftNumberTextBox.Size = new System.Drawing.Size(100, 21);
            this.leftNumberTextBox.TabIndex = 11;
            // 
            // leftNumberLabel
            // 
            this.leftNumberLabel.AutoSize = true;
            this.leftNumberLabel.Location = new System.Drawing.Point(46, 206);
            this.leftNumberLabel.Name = "leftNumberLabel";
            this.leftNumberLabel.Size = new System.Drawing.Size(41, 12);
            this.leftNumberLabel.TabIndex = 10;
            this.leftNumberLabel.Text = "label7";
            // 
            // capTextBox
            // 
            this.capTextBox.Enabled = false;
            this.capTextBox.Location = new System.Drawing.Point(44, 138);
            this.capTextBox.Name = "capTextBox";
            this.capTextBox.Size = new System.Drawing.Size(100, 21);
            this.capTextBox.TabIndex = 9;
            // 
            // capLabel
            // 
            this.capLabel.AutoSize = true;
            this.capLabel.Location = new System.Drawing.Point(44, 122);
            this.capLabel.Name = "capLabel";
            this.capLabel.Size = new System.Drawing.Size(41, 12);
            this.capLabel.TabIndex = 8;
            this.capLabel.Text = "label7";
            // 
            // totalNumberTextBox
            // 
            this.totalNumberTextBox.Enabled = false;
            this.totalNumberTextBox.Location = new System.Drawing.Point(44, 63);
            this.totalNumberTextBox.Name = "totalNumberTextBox";
            this.totalNumberTextBox.Size = new System.Drawing.Size(100, 21);
            this.totalNumberTextBox.TabIndex = 7;
            // 
            // totalNumberLabel
            // 
            this.totalNumberLabel.AutoSize = true;
            this.totalNumberLabel.Location = new System.Drawing.Point(42, 47);
            this.totalNumberLabel.Name = "totalNumberLabel";
            this.totalNumberLabel.Size = new System.Drawing.Size(41, 12);
            this.totalNumberLabel.TabIndex = 6;
            this.totalNumberLabel.Text = "label7";
            // 
            // settingPanel
            // 
            this.settingPanel.Controls.Add(this.groupBox1);
            this.settingPanel.Location = new System.Drawing.Point(4, 3);
            this.settingPanel.Name = "settingPanel";
            this.settingPanel.Size = new System.Drawing.Size(321, 301);
            this.settingPanel.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.setButton);
            this.groupBox1.Controls.Add(this.sampleTimeTextBox);
            this.groupBox1.Controls.Add(this.dispenTimeTextBox);
            this.groupBox1.Controls.Add(this.currency3TextBox);
            this.groupBox1.Controls.Add(this.currency2TextBox);
            this.groupBox1.Controls.Add(this.currency1TextBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.stateComboBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(315, 293);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设定";
            // 
            // setButton
            // 
            this.setButton.Location = new System.Drawing.Point(210, 255);
            this.setButton.Name = "setButton";
            this.setButton.Size = new System.Drawing.Size(75, 23);
            this.setButton.TabIndex = 25;
            this.setButton.Text = "设定";
            this.setButton.UseVisualStyleBackColor = true;
            this.setButton.Click += new System.EventHandler(this.setButton_Click);
            // 
            // sampleTimeTextBox
            // 
            this.sampleTimeTextBox.Location = new System.Drawing.Point(143, 205);
            this.sampleTimeTextBox.Name = "sampleTimeTextBox";
            this.sampleTimeTextBox.Size = new System.Drawing.Size(100, 21);
            this.sampleTimeTextBox.TabIndex = 24;
            // 
            // dispenTimeTextBox
            // 
            this.dispenTimeTextBox.Location = new System.Drawing.Point(143, 168);
            this.dispenTimeTextBox.Name = "dispenTimeTextBox";
            this.dispenTimeTextBox.Size = new System.Drawing.Size(100, 21);
            this.dispenTimeTextBox.TabIndex = 23;
            // 
            // currency3TextBox
            // 
            this.currency3TextBox.Location = new System.Drawing.Point(143, 132);
            this.currency3TextBox.Name = "currency3TextBox";
            this.currency3TextBox.Size = new System.Drawing.Size(100, 21);
            this.currency3TextBox.TabIndex = 22;
            // 
            // currency2TextBox
            // 
            this.currency2TextBox.Location = new System.Drawing.Point(143, 98);
            this.currency2TextBox.Name = "currency2TextBox";
            this.currency2TextBox.Size = new System.Drawing.Size(100, 21);
            this.currency2TextBox.TabIndex = 21;
            // 
            // currency1TextBox
            // 
            this.currency1TextBox.Location = new System.Drawing.Point(143, 62);
            this.currency1TextBox.Name = "currency1TextBox";
            this.currency1TextBox.Size = new System.Drawing.Size(100, 21);
            this.currency1TextBox.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "电流采样时间(S):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "分装处理时间(S):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 17;
            this.label4.Text = "电机3电流:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "电机2电流:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "电机1电流:";
            // 
            // stateComboBox
            // 
            this.stateComboBox.FormattingEnabled = true;
            this.stateComboBox.Location = new System.Drawing.Point(143, 26);
            this.stateComboBox.Name = "stateComboBox";
            this.stateComboBox.Size = new System.Drawing.Size(102, 20);
            this.stateComboBox.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "运行出错标志:";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // AutoDispenDeviceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 329);
            this.Controls.Add(this.panel1);
            this.Name = "AutoDispenDeviceForm";
            this.Text = "全自动培养基分装仪";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AutoDispenDeviceForm_FormClosing);
            this.Load += new System.EventHandler(this.AutoDispenDeviceForm_Load);
            this.panel1.ResumeLayout(false);
            this.displayPanel.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.settingPanel.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel settingPanel;
        private System.Windows.Forms.Panel displayPanel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button setButton;
        private System.Windows.Forms.TextBox sampleTimeTextBox;
        private System.Windows.Forms.TextBox dispenTimeTextBox;
        private System.Windows.Forms.TextBox currency3TextBox;
        private System.Windows.Forms.TextBox currency2TextBox;
        private System.Windows.Forms.TextBox currency1TextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox stateComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox leftNumberTextBox;
        private System.Windows.Forms.Label leftNumberLabel;
        private System.Windows.Forms.TextBox capTextBox;
        private System.Windows.Forms.Label capLabel;
        private System.Windows.Forms.TextBox totalNumberTextBox;
        private System.Windows.Forms.Label totalNumberLabel;
        private System.Windows.Forms.Timer timer1;
    }
}