﻿namespace VirtialDevices
{
    partial class MatrixSystemDeviceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("光强");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("x轴坐标");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("y轴坐标");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("当前占空比");
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("A");
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("B");
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("C");
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("D");
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("E");
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("F");
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("G");
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("H");
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem("A");
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem("B");
            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem("C");
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem("D");
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem("E");
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem("F");
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem("G");
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem("H");
            this.panel1 = new System.Windows.Forms.Panel();
            this.startButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.maDaTextBox = new System.Windows.Forms.TextBox();
            this.dianJiTextBox = new System.Windows.Forms.TextBox();
            this.yaoChuangTextBox = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.wenShiDuPanel = new System.Windows.Forms.Panel();
            this.chuShiYuZhiTextBox = new System.Windows.Forms.TextBox();
            this.jiaShiYuZhiTextBox = new System.Windows.Forms.TextBox();
            this.shiDuBaoJingTextBox = new System.Windows.Forms.TextBox();
            this.shiDuSheDingTextBox = new System.Windows.Forms.TextBox();
            this.wenDuKongZhiZhuangTaitextBox = new System.Windows.Forms.TextBox();
            this.wenDuKongZhiMoShiTextBox = new System.Windows.Forms.TextBox();
            this.chuShuangShiChangTextBox1 = new System.Windows.Forms.TextBox();
            this.chuShuangJianGeTextBox = new System.Windows.Forms.TextBox();
            this.jiaReGuanTextBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.yaSuoJiGongZuoZhuangTaiTextBox = new System.Windows.Forms.TextBox();
            this.wenDuSheDingTextBox = new System.Windows.Forms.TextBox();
            this.chaoWenTiaoZhengTextBox6 = new System.Windows.Forms.TextBox();
            this.diWenTiaoZhengTextBox = new System.Windows.Forms.TextBox();
            this.xiTongZhuangTaiTiaoZhengTextBox = new System.Windows.Forms.TextBox();
            this.chaoWenBaoJingTextBox = new System.Windows.Forms.TextBox();
            this.diWenBaoJingTextBox = new System.Windows.Forms.TextBox();
            this.yaSuoJiGongZuoMoShiTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.yunGuangPanel = new System.Windows.Forms.Panel();
            this.guangQiangTextBox = new System.Windows.Forms.TextBox();
            this.zhanKongBiTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.deviceSystemPanel = new System.Windows.Forms.Panel();
            this.runCommandTextBox = new System.Windows.Forms.TextBox();
            this.runTypeTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.yiChuTiaoMaTextBox = new System.Windows.Forms.TextBox();
            this.peiYangShiJianTextBox = new System.Windows.Forms.TextBox();
            this.yiRuTiaoMaTextBox = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dianJiGongLvTextBox = new System.Windows.Forms.TextBox();
            this.dianJiZhuanSuTextBox = new System.Windows.Forms.TextBox();
            this.yaoChuangZhuanSuTextBox = new System.Windows.Forms.TextBox();
            this.dianJiZhuangTaiTextBox = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.shiDu2TextBox = new System.Windows.Forms.TextBox();
            this.shiDu1TextBox = new System.Windows.Forms.TextBox();
            this.wenShiZhuangTaiTextBox = new System.Windows.Forms.TextBox();
            this.wenDu3TextBox = new System.Windows.Forms.TextBox();
            this.wenDu2TextBox = new System.Windows.Forms.TextBox();
            this.wenDu1TextBox = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.zuoYeZhuangTaiTextBox = new System.Windows.Forms.TextBox();
            this.yiQiZhuangTaiTextBox = new System.Windows.Forms.TextBox();
            this.sheBeiXinXiTextBox = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.listView2 = new System.Windows.Forms.ListView();
            this.locationColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.codeColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label53 = new System.Windows.Forms.Label();
            this.dataListView = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.wenShiDuPanel.SuspendLayout();
            this.yunGuangPanel.SuspendLayout();
            this.deviceSystemPanel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.startButton);
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(684, 575);
            this.panel1.TabIndex = 0;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(148, 541);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 14;
            this.startButton.Text = "开始模拟";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(562, 542);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "退出";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(16, 541);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "保存";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(678, 532);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(670, 507);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "显示";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.wenShiDuPanel);
            this.panel2.Controls.Add(this.yunGuangPanel);
            this.panel2.Controls.Add(this.deviceSystemPanel);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(658, 497);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.maDaTextBox);
            this.panel3.Controls.Add(this.dianJiTextBox);
            this.panel3.Controls.Add(this.yaoChuangTextBox);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Location = new System.Drawing.Point(3, 400);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(652, 94);
            this.panel3.TabIndex = 3;
            // 
            // maDaTextBox
            // 
            this.maDaTextBox.Location = new System.Drawing.Point(446, 27);
            this.maDaTextBox.Name = "maDaTextBox";
            this.maDaTextBox.Size = new System.Drawing.Size(157, 21);
            this.maDaTextBox.TabIndex = 29;
            // 
            // dianJiTextBox
            // 
            this.dianJiTextBox.Location = new System.Drawing.Point(129, 55);
            this.dianJiTextBox.Name = "dianJiTextBox";
            this.dianJiTextBox.Size = new System.Drawing.Size(157, 21);
            this.dianJiTextBox.TabIndex = 28;
            // 
            // yaoChuangTextBox
            // 
            this.yaoChuangTextBox.Location = new System.Drawing.Point(129, 28);
            this.yaoChuangTextBox.Name = "yaoChuangTextBox";
            this.yaoChuangTextBox.Size = new System.Drawing.Size(157, 21);
            this.yaoChuangTextBox.TabIndex = 27;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(343, 31);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 12);
            this.label28.TabIndex = 3;
            this.label28.Text = "马达斜率:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(28, 58);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 12);
            this.label27.TabIndex = 2;
            this.label27.Text = "电机转速:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(29, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 12);
            this.label26.TabIndex = 1;
            this.label26.Text = "摇床转速:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(20, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "电机";
            // 
            // wenShiDuPanel
            // 
            this.wenShiDuPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wenShiDuPanel.Controls.Add(this.chuShiYuZhiTextBox);
            this.wenShiDuPanel.Controls.Add(this.jiaShiYuZhiTextBox);
            this.wenShiDuPanel.Controls.Add(this.shiDuBaoJingTextBox);
            this.wenShiDuPanel.Controls.Add(this.shiDuSheDingTextBox);
            this.wenShiDuPanel.Controls.Add(this.wenDuKongZhiZhuangTaitextBox);
            this.wenShiDuPanel.Controls.Add(this.wenDuKongZhiMoShiTextBox);
            this.wenShiDuPanel.Controls.Add(this.chuShuangShiChangTextBox1);
            this.wenShiDuPanel.Controls.Add(this.chuShuangJianGeTextBox);
            this.wenShiDuPanel.Controls.Add(this.jiaReGuanTextBox);
            this.wenShiDuPanel.Controls.Add(this.label24);
            this.wenShiDuPanel.Controls.Add(this.label23);
            this.wenShiDuPanel.Controls.Add(this.label22);
            this.wenShiDuPanel.Controls.Add(this.label21);
            this.wenShiDuPanel.Controls.Add(this.label20);
            this.wenShiDuPanel.Controls.Add(this.label19);
            this.wenShiDuPanel.Controls.Add(this.label18);
            this.wenShiDuPanel.Controls.Add(this.label17);
            this.wenShiDuPanel.Controls.Add(this.label16);
            this.wenShiDuPanel.Controls.Add(this.yaSuoJiGongZuoZhuangTaiTextBox);
            this.wenShiDuPanel.Controls.Add(this.wenDuSheDingTextBox);
            this.wenShiDuPanel.Controls.Add(this.chaoWenTiaoZhengTextBox6);
            this.wenShiDuPanel.Controls.Add(this.diWenTiaoZhengTextBox);
            this.wenShiDuPanel.Controls.Add(this.xiTongZhuangTaiTiaoZhengTextBox);
            this.wenShiDuPanel.Controls.Add(this.chaoWenBaoJingTextBox);
            this.wenShiDuPanel.Controls.Add(this.diWenBaoJingTextBox);
            this.wenShiDuPanel.Controls.Add(this.yaSuoJiGongZuoMoShiTextBox);
            this.wenShiDuPanel.Controls.Add(this.label15);
            this.wenShiDuPanel.Controls.Add(this.label14);
            this.wenShiDuPanel.Controls.Add(this.label13);
            this.wenShiDuPanel.Controls.Add(this.label12);
            this.wenShiDuPanel.Controls.Add(this.label11);
            this.wenShiDuPanel.Controls.Add(this.label10);
            this.wenShiDuPanel.Controls.Add(this.label9);
            this.wenShiDuPanel.Controls.Add(this.label8);
            this.wenShiDuPanel.Controls.Add(this.label7);
            this.wenShiDuPanel.Location = new System.Drawing.Point(3, 121);
            this.wenShiDuPanel.Name = "wenShiDuPanel";
            this.wenShiDuPanel.Size = new System.Drawing.Size(652, 278);
            this.wenShiDuPanel.TabIndex = 2;
            // 
            // chuShiYuZhiTextBox
            // 
            this.chuShiYuZhiTextBox.Location = new System.Drawing.Point(447, 221);
            this.chuShiYuZhiTextBox.Name = "chuShiYuZhiTextBox";
            this.chuShiYuZhiTextBox.Size = new System.Drawing.Size(157, 21);
            this.chuShiYuZhiTextBox.TabIndex = 34;
            // 
            // jiaShiYuZhiTextBox
            // 
            this.jiaShiYuZhiTextBox.Location = new System.Drawing.Point(447, 194);
            this.jiaShiYuZhiTextBox.Name = "jiaShiYuZhiTextBox";
            this.jiaShiYuZhiTextBox.Size = new System.Drawing.Size(157, 21);
            this.jiaShiYuZhiTextBox.TabIndex = 33;
            // 
            // shiDuBaoJingTextBox
            // 
            this.shiDuBaoJingTextBox.Location = new System.Drawing.Point(447, 167);
            this.shiDuBaoJingTextBox.Name = "shiDuBaoJingTextBox";
            this.shiDuBaoJingTextBox.Size = new System.Drawing.Size(157, 21);
            this.shiDuBaoJingTextBox.TabIndex = 32;
            // 
            // shiDuSheDingTextBox
            // 
            this.shiDuSheDingTextBox.Location = new System.Drawing.Point(447, 140);
            this.shiDuSheDingTextBox.Name = "shiDuSheDingTextBox";
            this.shiDuSheDingTextBox.Size = new System.Drawing.Size(157, 21);
            this.shiDuSheDingTextBox.TabIndex = 31;
            // 
            // wenDuKongZhiZhuangTaitextBox
            // 
            this.wenDuKongZhiZhuangTaitextBox.Location = new System.Drawing.Point(447, 113);
            this.wenDuKongZhiZhuangTaitextBox.Name = "wenDuKongZhiZhuangTaitextBox";
            this.wenDuKongZhiZhuangTaitextBox.Size = new System.Drawing.Size(157, 21);
            this.wenDuKongZhiZhuangTaitextBox.TabIndex = 30;
            // 
            // wenDuKongZhiMoShiTextBox
            // 
            this.wenDuKongZhiMoShiTextBox.Location = new System.Drawing.Point(447, 86);
            this.wenDuKongZhiMoShiTextBox.Name = "wenDuKongZhiMoShiTextBox";
            this.wenDuKongZhiMoShiTextBox.Size = new System.Drawing.Size(157, 21);
            this.wenDuKongZhiMoShiTextBox.TabIndex = 29;
            // 
            // chuShuangShiChangTextBox1
            // 
            this.chuShuangShiChangTextBox1.Location = new System.Drawing.Point(447, 59);
            this.chuShuangShiChangTextBox1.Name = "chuShuangShiChangTextBox1";
            this.chuShuangShiChangTextBox1.Size = new System.Drawing.Size(157, 21);
            this.chuShuangShiChangTextBox1.TabIndex = 28;
            // 
            // chuShuangJianGeTextBox
            // 
            this.chuShuangJianGeTextBox.Location = new System.Drawing.Point(447, 32);
            this.chuShuangJianGeTextBox.Name = "chuShuangJianGeTextBox";
            this.chuShuangJianGeTextBox.Size = new System.Drawing.Size(157, 21);
            this.chuShuangJianGeTextBox.TabIndex = 27;
            // 
            // jiaReGuanTextBox
            // 
            this.jiaReGuanTextBox.Location = new System.Drawing.Point(131, 251);
            this.jiaReGuanTextBox.Name = "jiaReGuanTextBox";
            this.jiaReGuanTextBox.Size = new System.Drawing.Size(157, 21);
            this.jiaReGuanTextBox.TabIndex = 26;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(346, 224);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 12);
            this.label24.TabIndex = 25;
            this.label24.Text = "除湿阈值:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(346, 197);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 12);
            this.label23.TabIndex = 24;
            this.label23.Text = "加湿阈值:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(346, 170);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 23;
            this.label22.Text = "湿度报警阈值";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(344, 143);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 12);
            this.label21.TabIndex = 22;
            this.label21.Text = "湿度设定值:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(346, 116);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 12);
            this.label20.TabIndex = 21;
            this.label20.Text = "温度控制状态:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(346, 89);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 12);
            this.label19.TabIndex = 20;
            this.label19.Text = "温度控制模式:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(30, 254);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 12);
            this.label18.TabIndex = 19;
            this.label18.Text = "加热管:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(346, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 12);
            this.label17.TabIndex = 18;
            this.label17.Text = "除霜时长:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(346, 35);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 12);
            this.label16.TabIndex = 17;
            this.label16.Text = "除霜机除霜间隔:";
            // 
            // yaSuoJiGongZuoZhuangTaiTextBox
            // 
            this.yaSuoJiGongZuoZhuangTaiTextBox.Location = new System.Drawing.Point(131, 224);
            this.yaSuoJiGongZuoZhuangTaiTextBox.Name = "yaSuoJiGongZuoZhuangTaiTextBox";
            this.yaSuoJiGongZuoZhuangTaiTextBox.Size = new System.Drawing.Size(157, 21);
            this.yaSuoJiGongZuoZhuangTaiTextBox.TabIndex = 16;
            // 
            // wenDuSheDingTextBox
            // 
            this.wenDuSheDingTextBox.Location = new System.Drawing.Point(131, 32);
            this.wenDuSheDingTextBox.Name = "wenDuSheDingTextBox";
            this.wenDuSheDingTextBox.Size = new System.Drawing.Size(157, 21);
            this.wenDuSheDingTextBox.TabIndex = 15;
            // 
            // chaoWenTiaoZhengTextBox6
            // 
            this.chaoWenTiaoZhengTextBox6.Location = new System.Drawing.Point(131, 59);
            this.chaoWenTiaoZhengTextBox6.Name = "chaoWenTiaoZhengTextBox6";
            this.chaoWenTiaoZhengTextBox6.Size = new System.Drawing.Size(157, 21);
            this.chaoWenTiaoZhengTextBox6.TabIndex = 14;
            // 
            // diWenTiaoZhengTextBox
            // 
            this.diWenTiaoZhengTextBox.Location = new System.Drawing.Point(131, 88);
            this.diWenTiaoZhengTextBox.Name = "diWenTiaoZhengTextBox";
            this.diWenTiaoZhengTextBox.Size = new System.Drawing.Size(157, 21);
            this.diWenTiaoZhengTextBox.TabIndex = 13;
            // 
            // xiTongZhuangTaiTiaoZhengTextBox
            // 
            this.xiTongZhuangTaiTiaoZhengTextBox.Location = new System.Drawing.Point(131, 116);
            this.xiTongZhuangTaiTiaoZhengTextBox.Name = "xiTongZhuangTaiTiaoZhengTextBox";
            this.xiTongZhuangTaiTiaoZhengTextBox.Size = new System.Drawing.Size(157, 21);
            this.xiTongZhuangTaiTiaoZhengTextBox.TabIndex = 12;
            // 
            // chaoWenBaoJingTextBox
            // 
            this.chaoWenBaoJingTextBox.Location = new System.Drawing.Point(131, 143);
            this.chaoWenBaoJingTextBox.Name = "chaoWenBaoJingTextBox";
            this.chaoWenBaoJingTextBox.Size = new System.Drawing.Size(157, 21);
            this.chaoWenBaoJingTextBox.TabIndex = 11;
            // 
            // diWenBaoJingTextBox
            // 
            this.diWenBaoJingTextBox.Location = new System.Drawing.Point(131, 170);
            this.diWenBaoJingTextBox.Name = "diWenBaoJingTextBox";
            this.diWenBaoJingTextBox.Size = new System.Drawing.Size(157, 21);
            this.diWenBaoJingTextBox.TabIndex = 10;
            // 
            // yaSuoJiGongZuoMoShiTextBox
            // 
            this.yaSuoJiGongZuoMoShiTextBox.Location = new System.Drawing.Point(130, 197);
            this.yaSuoJiGongZuoMoShiTextBox.Name = "yaSuoJiGongZuoMoShiTextBox";
            this.yaSuoJiGongZuoMoShiTextBox.Size = new System.Drawing.Size(158, 21);
            this.yaSuoJiGongZuoMoShiTextBox.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(30, 227);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 12);
            this.label15.TabIndex = 8;
            this.label15.Text = "压缩机工作状态:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 200);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 12);
            this.label14.TabIndex = 7;
            this.label14.Text = "压缩机工作模式:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(30, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 12);
            this.label13.TabIndex = 6;
            this.label13.Text = "低温报警阈值:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 146);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "超温报警阈值:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 4;
            this.label11.Text = "系统状态调整";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 12);
            this.label10.TabIndex = 3;
            this.label10.Text = "低温调整阈值:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "超温调整阈值:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "温度设定值:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "温湿度";
            // 
            // yunGuangPanel
            // 
            this.yunGuangPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yunGuangPanel.Controls.Add(this.guangQiangTextBox);
            this.yunGuangPanel.Controls.Add(this.zhanKongBiTextBox);
            this.yunGuangPanel.Controls.Add(this.label6);
            this.yunGuangPanel.Controls.Add(this.label5);
            this.yunGuangPanel.Controls.Add(this.label4);
            this.yunGuangPanel.Location = new System.Drawing.Point(325, 3);
            this.yunGuangPanel.Name = "yunGuangPanel";
            this.yunGuangPanel.Size = new System.Drawing.Size(330, 112);
            this.yunGuangPanel.TabIndex = 1;
            // 
            // guangQiangTextBox
            // 
            this.guangQiangTextBox.Location = new System.Drawing.Point(145, 66);
            this.guangQiangTextBox.Name = "guangQiangTextBox";
            this.guangQiangTextBox.Size = new System.Drawing.Size(145, 21);
            this.guangQiangTextBox.TabIndex = 4;
            // 
            // zhanKongBiTextBox
            // 
            this.zhanKongBiTextBox.Location = new System.Drawing.Point(145, 38);
            this.zhanKongBiTextBox.Name = "zhanKongBiTextBox";
            this.zhanKongBiTextBox.Size = new System.Drawing.Size(145, 21);
            this.zhanKongBiTextBox.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "光强设置:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "占空比设置请求:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "匀光";
            // 
            // deviceSystemPanel
            // 
            this.deviceSystemPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.deviceSystemPanel.Controls.Add(this.runCommandTextBox);
            this.deviceSystemPanel.Controls.Add(this.runTypeTextBox);
            this.deviceSystemPanel.Controls.Add(this.label3);
            this.deviceSystemPanel.Controls.Add(this.label2);
            this.deviceSystemPanel.Controls.Add(this.label1);
            this.deviceSystemPanel.Location = new System.Drawing.Point(3, 3);
            this.deviceSystemPanel.Name = "deviceSystemPanel";
            this.deviceSystemPanel.Size = new System.Drawing.Size(316, 112);
            this.deviceSystemPanel.TabIndex = 0;
            // 
            // runCommandTextBox
            // 
            this.runCommandTextBox.Location = new System.Drawing.Point(94, 65);
            this.runCommandTextBox.Name = "runCommandTextBox";
            this.runCommandTextBox.Size = new System.Drawing.Size(136, 21);
            this.runCommandTextBox.TabIndex = 4;
            // 
            // runTypeTextBox
            // 
            this.runTypeTextBox.Location = new System.Drawing.Point(94, 38);
            this.runTypeTextBox.Name = "runTypeTextBox";
            this.runTypeTextBox.Size = new System.Drawing.Size(136, 21);
            this.runTypeTextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "运行命令:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "运行模式:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "仪器系统";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(670, 507);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "数据";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(6, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(658, 497);
            this.panel4.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.yiChuTiaoMaTextBox);
            this.panel9.Controls.Add(this.peiYangShiJianTextBox);
            this.panel9.Controls.Add(this.yiRuTiaoMaTextBox);
            this.panel9.Controls.Add(this.label50);
            this.panel9.Controls.Add(this.label49);
            this.panel9.Controls.Add(this.label48);
            this.panel9.Controls.Add(this.label47);
            this.panel9.Location = new System.Drawing.Point(3, 425);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(652, 69);
            this.panel9.TabIndex = 4;
            // 
            // yiChuTiaoMaTextBox
            // 
            this.yiChuTiaoMaTextBox.Location = new System.Drawing.Point(448, 15);
            this.yiChuTiaoMaTextBox.Name = "yiChuTiaoMaTextBox";
            this.yiChuTiaoMaTextBox.Size = new System.Drawing.Size(172, 21);
            this.yiChuTiaoMaTextBox.TabIndex = 13;
            // 
            // peiYangShiJianTextBox
            // 
            this.peiYangShiJianTextBox.Location = new System.Drawing.Point(131, 42);
            this.peiYangShiJianTextBox.Name = "peiYangShiJianTextBox";
            this.peiYangShiJianTextBox.Size = new System.Drawing.Size(172, 21);
            this.peiYangShiJianTextBox.TabIndex = 12;
            // 
            // yiRuTiaoMaTextBox
            // 
            this.yiRuTiaoMaTextBox.Location = new System.Drawing.Point(131, 15);
            this.yiRuTiaoMaTextBox.Name = "yiRuTiaoMaTextBox";
            this.yiRuTiaoMaTextBox.Size = new System.Drawing.Size(172, 21);
            this.yiRuTiaoMaTextBox.TabIndex = 11;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(38, 47);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(101, 12);
            this.label50.TabIndex = 3;
            this.label50.Text = "培养时间(小时)：";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(330, 21);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(89, 12);
            this.label49.TabIndex = 2;
            this.label49.Text = "移出容器条码：";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(38, 19);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(89, 12);
            this.label48.TabIndex = 1;
            this.label48.Text = "移入容器条码：";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(20, 5);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "条码";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.dianJiGongLvTextBox);
            this.panel8.Controls.Add(this.dianJiZhuanSuTextBox);
            this.panel8.Controls.Add(this.yaoChuangZhuanSuTextBox);
            this.panel8.Controls.Add(this.dianJiZhuangTaiTextBox);
            this.panel8.Controls.Add(this.label46);
            this.panel8.Controls.Add(this.label45);
            this.panel8.Controls.Add(this.label44);
            this.panel8.Controls.Add(this.label43);
            this.panel8.Controls.Add(this.label42);
            this.panel8.Location = new System.Drawing.Point(3, 346);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(652, 77);
            this.panel8.TabIndex = 3;
            // 
            // dianJiGongLvTextBox
            // 
            this.dianJiGongLvTextBox.Location = new System.Drawing.Point(448, 46);
            this.dianJiGongLvTextBox.Name = "dianJiGongLvTextBox";
            this.dianJiGongLvTextBox.Size = new System.Drawing.Size(172, 21);
            this.dianJiGongLvTextBox.TabIndex = 12;
            // 
            // dianJiZhuanSuTextBox
            // 
            this.dianJiZhuanSuTextBox.Location = new System.Drawing.Point(448, 19);
            this.dianJiZhuanSuTextBox.Name = "dianJiZhuanSuTextBox";
            this.dianJiZhuanSuTextBox.Size = new System.Drawing.Size(172, 21);
            this.dianJiZhuanSuTextBox.TabIndex = 11;
            // 
            // yaoChuangZhuanSuTextBox
            // 
            this.yaoChuangZhuanSuTextBox.Location = new System.Drawing.Point(131, 46);
            this.yaoChuangZhuanSuTextBox.Name = "yaoChuangZhuanSuTextBox";
            this.yaoChuangZhuanSuTextBox.Size = new System.Drawing.Size(172, 21);
            this.yaoChuangZhuanSuTextBox.TabIndex = 10;
            // 
            // dianJiZhuangTaiTextBox
            // 
            this.dianJiZhuangTaiTextBox.Location = new System.Drawing.Point(131, 19);
            this.dianJiZhuangTaiTextBox.Name = "dianJiZhuangTaiTextBox";
            this.dianJiZhuangTaiTextBox.Size = new System.Drawing.Size(172, 21);
            this.dianJiZhuangTaiTextBox.TabIndex = 9;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(332, 52);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 12);
            this.label46.TabIndex = 4;
            this.label46.Text = "电机功率：";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(330, 25);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(65, 12);
            this.label45.TabIndex = 3;
            this.label45.Text = "电机转速：";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(36, 51);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 12);
            this.label44.TabIndex = 2;
            this.label44.Text = "摇床转速：";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(36, 26);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(89, 12);
            this.label43.TabIndex = 1;
            this.label43.Text = "模块工作状态：";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(18, 5);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(29, 12);
            this.label42.TabIndex = 0;
            this.label42.Text = "电机";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.shiDu2TextBox);
            this.panel7.Controls.Add(this.shiDu1TextBox);
            this.panel7.Controls.Add(this.wenShiZhuangTaiTextBox);
            this.panel7.Controls.Add(this.wenDu3TextBox);
            this.panel7.Controls.Add(this.wenDu2TextBox);
            this.panel7.Controls.Add(this.wenDu1TextBox);
            this.panel7.Controls.Add(this.label41);
            this.panel7.Controls.Add(this.label40);
            this.panel7.Controls.Add(this.label39);
            this.panel7.Controls.Add(this.label38);
            this.panel7.Controls.Add(this.label37);
            this.panel7.Controls.Add(this.label36);
            this.panel7.Controls.Add(this.label35);
            this.panel7.Location = new System.Drawing.Point(3, 236);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(652, 108);
            this.panel7.TabIndex = 2;
            // 
            // shiDu2TextBox
            // 
            this.shiDu2TextBox.Location = new System.Drawing.Point(449, 77);
            this.shiDu2TextBox.Name = "shiDu2TextBox";
            this.shiDu2TextBox.Size = new System.Drawing.Size(172, 21);
            this.shiDu2TextBox.TabIndex = 12;
            // 
            // shiDu1TextBox
            // 
            this.shiDu1TextBox.Location = new System.Drawing.Point(449, 50);
            this.shiDu1TextBox.Name = "shiDu1TextBox";
            this.shiDu1TextBox.Size = new System.Drawing.Size(172, 21);
            this.shiDu1TextBox.TabIndex = 11;
            // 
            // wenShiZhuangTaiTextBox
            // 
            this.wenShiZhuangTaiTextBox.Location = new System.Drawing.Point(449, 23);
            this.wenShiZhuangTaiTextBox.Name = "wenShiZhuangTaiTextBox";
            this.wenShiZhuangTaiTextBox.Size = new System.Drawing.Size(172, 21);
            this.wenShiZhuangTaiTextBox.TabIndex = 10;
            // 
            // wenDu3TextBox
            // 
            this.wenDu3TextBox.Location = new System.Drawing.Point(131, 77);
            this.wenDu3TextBox.Name = "wenDu3TextBox";
            this.wenDu3TextBox.Size = new System.Drawing.Size(172, 21);
            this.wenDu3TextBox.TabIndex = 9;
            // 
            // wenDu2TextBox
            // 
            this.wenDu2TextBox.Location = new System.Drawing.Point(131, 50);
            this.wenDu2TextBox.Name = "wenDu2TextBox";
            this.wenDu2TextBox.Size = new System.Drawing.Size(172, 21);
            this.wenDu2TextBox.TabIndex = 8;
            // 
            // wenDu1TextBox
            // 
            this.wenDu1TextBox.Location = new System.Drawing.Point(131, 23);
            this.wenDu1TextBox.Name = "wenDu1TextBox";
            this.wenDu1TextBox.Size = new System.Drawing.Size(172, 21);
            this.wenDu1TextBox.TabIndex = 7;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(328, 82);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(47, 12);
            this.label41.TabIndex = 6;
            this.label41.Text = "湿度2：";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(328, 55);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(47, 12);
            this.label40.TabIndex = 5;
            this.label40.Text = "湿度1：";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(328, 27);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 12);
            this.label39.TabIndex = 4;
            this.label39.Text = "模块工作状态：";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(36, 82);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(47, 12);
            this.label38.TabIndex = 3;
            this.label38.Text = "温度3：";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(36, 55);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(47, 12);
            this.label37.TabIndex = 2;
            this.label37.Text = "温度2：";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(36, 26);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(47, 12);
            this.label36.TabIndex = 1;
            this.label36.Text = "温度1：";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(18, 5);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "温湿度";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.listView1);
            this.panel6.Controls.Add(this.label34);
            this.panel6.Controls.Add(this.label33);
            this.panel6.Location = new System.Drawing.Point(3, 83);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(652, 151);
            this.panel6.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.listView1.GridLines = true;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4});
            this.listView1.Location = new System.Drawing.Point(38, 45);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(566, 95);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader
            // 
            this.columnHeader.Text = "地址";
            this.columnHeader.Width = 80;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "1";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "2";
            this.columnHeader2.Width = 40;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "3";
            this.columnHeader3.Width = 40;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "4";
            this.columnHeader4.Width = 40;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "5";
            this.columnHeader5.Width = 40;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "6";
            this.columnHeader6.Width = 40;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "7";
            this.columnHeader7.Width = 40;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "8";
            this.columnHeader8.Width = 40;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "8";
            this.columnHeader9.Width = 40;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "10";
            this.columnHeader10.Width = 40;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "11";
            this.columnHeader11.Width = 40;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "12";
            this.columnHeader12.Width = 40;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(38, 26);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 12);
            this.label34.TabIndex = 1;
            this.label34.Text = "模块工作状态";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(20, 6);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "匀光";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.zuoYeZhuangTaiTextBox);
            this.panel5.Controls.Add(this.yiQiZhuangTaiTextBox);
            this.panel5.Controls.Add(this.sheBeiXinXiTextBox);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label30);
            this.panel5.Controls.Add(this.label29);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(652, 78);
            this.panel5.TabIndex = 0;
            // 
            // zuoYeZhuangTaiTextBox
            // 
            this.zuoYeZhuangTaiTextBox.Location = new System.Drawing.Point(449, 22);
            this.zuoYeZhuangTaiTextBox.Name = "zuoYeZhuangTaiTextBox";
            this.zuoYeZhuangTaiTextBox.Size = new System.Drawing.Size(172, 21);
            this.zuoYeZhuangTaiTextBox.TabIndex = 6;
            // 
            // yiQiZhuangTaiTextBox
            // 
            this.yiQiZhuangTaiTextBox.Location = new System.Drawing.Point(131, 49);
            this.yiQiZhuangTaiTextBox.Name = "yiQiZhuangTaiTextBox";
            this.yiQiZhuangTaiTextBox.Size = new System.Drawing.Size(172, 21);
            this.yiQiZhuangTaiTextBox.TabIndex = 5;
            // 
            // sheBeiXinXiTextBox
            // 
            this.sheBeiXinXiTextBox.Location = new System.Drawing.Point(131, 22);
            this.sheBeiXinXiTextBox.Name = "sheBeiXinXiTextBox";
            this.sheBeiXinXiTextBox.Size = new System.Drawing.Size(172, 21);
            this.sheBeiXinXiTextBox.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(343, 26);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(89, 12);
            this.label32.TabIndex = 3;
            this.label32.Text = "作业状态信息：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(36, 53);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(89, 12);
            this.label31.TabIndex = 2;
            this.label31.Text = "仪器工作状态：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(36, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 1;
            this.label30.Text = "设备信息：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(18, 6);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "仪器系统";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(670, 507);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "OD数据";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.listView2);
            this.panel10.Controls.Add(this.label53);
            this.panel10.Controls.Add(this.dataListView);
            this.panel10.Controls.Add(this.comboBox1);
            this.panel10.Controls.Add(this.label52);
            this.panel10.Controls.Add(this.label51);
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(664, 500);
            this.panel10.TabIndex = 0;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.locationColumnHeader,
            this.codeColumnHeader,
            this.columnColumnHeader,
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader31,
            this.columnHeader32,
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader35,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader38,
            this.columnHeader39,
            this.columnHeader40});
            this.listView2.GridLines = true;
            this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12});
            this.listView2.Location = new System.Drawing.Point(6, 262);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(647, 158);
            this.listView2.TabIndex = 19;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            this.listView2.SelectedIndexChanged += new System.EventHandler(this.listView2_SelectedIndexChanged);
            // 
            // locationColumnHeader
            // 
            this.locationColumnHeader.Text = "孔板位置";
            this.locationColumnHeader.Width = 88;
            // 
            // codeColumnHeader
            // 
            this.codeColumnHeader.Text = "条码";
            this.codeColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnColumnHeader
            // 
            this.columnColumnHeader.Text = "孔列";
            this.columnColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnColumnHeader.Width = 40;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "孔1";
            this.columnHeader29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader29.Width = 40;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "孔2";
            this.columnHeader30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader30.Width = 40;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "孔3";
            this.columnHeader31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader31.Width = 41;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "孔4";
            this.columnHeader32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader32.Width = 40;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "孔5";
            this.columnHeader33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader33.Width = 40;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "孔6";
            this.columnHeader34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader34.Width = 40;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "孔7";
            this.columnHeader35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader35.Width = 40;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "孔8";
            this.columnHeader36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader36.Width = 40;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "孔9";
            this.columnHeader37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader37.Width = 40;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "孔10";
            this.columnHeader38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader38.Width = 40;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "孔11";
            this.columnHeader39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader39.Width = 39;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "孔12";
            this.columnHeader40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader40.Width = 40;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(25, 247);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(65, 12);
            this.label53.TabIndex = 18;
            this.label53.Text = "表格样式：";
            // 
            // dataListView
            // 
            this.dataListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25});
            this.dataListView.GridLines = true;
            this.dataListView.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem13,
            listViewItem14,
            listViewItem15,
            listViewItem16,
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20});
            this.dataListView.Location = new System.Drawing.Point(36, 63);
            this.dataListView.Name = "dataListView";
            this.dataListView.Size = new System.Drawing.Size(523, 158);
            this.dataListView.TabIndex = 17;
            this.dataListView.UseCompatibleStateImageBehavior = false;
            this.dataListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "";
            this.columnHeader13.Width = 30;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "1";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader14.Width = 40;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "2";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 40;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "3";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 40;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "4";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader17.Width = 40;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "5";
            this.columnHeader18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader18.Width = 40;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "6";
            this.columnHeader19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader19.Width = 40;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "7";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader20.Width = 40;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "8";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader21.Width = 40;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "9";
            this.columnHeader22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader22.Width = 40;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "10";
            this.columnHeader23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader23.Width = 40;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "11";
            this.columnHeader24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader24.Width = 40;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "12";
            this.columnHeader25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader25.Width = 40;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "第一个",
            "第二个",
            "第三个",
            "第四个",
            "第五个",
            "第六个"});
            this.comboBox1.Location = new System.Drawing.Point(106, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 2;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(34, 40);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(65, 12);
            this.label52.TabIndex = 1;
            this.label52.Text = "表格索引：";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(23, 14);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "OD值";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MatrixSystemDeviceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 599);
            this.Controls.Add(this.panel1);
            this.Name = "MatrixSystemDeviceForm";
            this.Text = "阵列式高通量培养仪";
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.wenShiDuPanel.ResumeLayout(false);
            this.wenShiDuPanel.PerformLayout();
            this.yunGuangPanel.ResumeLayout(false);
            this.yunGuangPanel.PerformLayout();
            this.deviceSystemPanel.ResumeLayout(false);
            this.deviceSystemPanel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel deviceSystemPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox runTypeTextBox;
        private System.Windows.Forms.TextBox runCommandTextBox;
        private System.Windows.Forms.Panel yunGuangPanel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox guangQiangTextBox;
        private System.Windows.Forms.TextBox zhanKongBiTextBox;
        private System.Windows.Forms.Panel wenShiDuPanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox yaSuoJiGongZuoMoShiTextBox;
        private System.Windows.Forms.TextBox diWenBaoJingTextBox;
        private System.Windows.Forms.TextBox chaoWenBaoJingTextBox;
        private System.Windows.Forms.TextBox yaSuoJiGongZuoZhuangTaiTextBox;
        private System.Windows.Forms.TextBox wenDuSheDingTextBox;
        private System.Windows.Forms.TextBox chaoWenTiaoZhengTextBox6;
        private System.Windows.Forms.TextBox diWenTiaoZhengTextBox;
        private System.Windows.Forms.TextBox xiTongZhuangTaiTiaoZhengTextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox jiaReGuanTextBox;
        private System.Windows.Forms.TextBox chuShiYuZhiTextBox;
        private System.Windows.Forms.TextBox jiaShiYuZhiTextBox;
        private System.Windows.Forms.TextBox shiDuBaoJingTextBox;
        private System.Windows.Forms.TextBox shiDuSheDingTextBox;
        private System.Windows.Forms.TextBox wenDuKongZhiZhuangTaitextBox;
        private System.Windows.Forms.TextBox wenDuKongZhiMoShiTextBox;
        private System.Windows.Forms.TextBox chuShuangShiChangTextBox1;
        private System.Windows.Forms.TextBox chuShuangJianGeTextBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox maDaTextBox;
        private System.Windows.Forms.TextBox dianJiTextBox;
        private System.Windows.Forms.TextBox yaoChuangTextBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox zuoYeZhuangTaiTextBox;
        private System.Windows.Forms.TextBox yiQiZhuangTaiTextBox;
        private System.Windows.Forms.TextBox sheBeiXinXiTextBox;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox wenDu3TextBox;
        private System.Windows.Forms.TextBox wenDu2TextBox;
        private System.Windows.Forms.TextBox wenDu1TextBox;
        private System.Windows.Forms.TextBox shiDu2TextBox;
        private System.Windows.Forms.TextBox shiDu1TextBox;
        private System.Windows.Forms.TextBox wenShiZhuangTaiTextBox;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox dianJiZhuangTaiTextBox;
        private System.Windows.Forms.TextBox yaoChuangZhuanSuTextBox;
        private System.Windows.Forms.TextBox dianJiGongLvTextBox;
        private System.Windows.Forms.TextBox dianJiZhuanSuTextBox;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox peiYangShiJianTextBox;
        private System.Windows.Forms.TextBox yiRuTiaoMaTextBox;
        private System.Windows.Forms.TextBox yiChuTiaoMaTextBox;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ListView dataListView;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader locationColumnHeader;
        private System.Windows.Forms.ColumnHeader codeColumnHeader;
        private System.Windows.Forms.ColumnHeader columnColumnHeader;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button startButton;
    }
}